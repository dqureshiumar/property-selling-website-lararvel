<footer class="footer">
    <?php echo $__env->make('layouts.footers.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</footer><?php /**PATH C:\Users\dqure\Desktop\property\property\resources\views/layouts/footers/auth.blade.php ENDPATH**/ ?>