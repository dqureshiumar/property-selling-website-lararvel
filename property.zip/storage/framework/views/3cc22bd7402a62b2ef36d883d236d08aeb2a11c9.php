Hello <strong><?php echo e($name); ?></strong>,
<p><?php echo e($body); ?></p><?php /**PATH C:\Users\dqure\Desktop\homex\property\resources\views/emails/mail.blade.php ENDPATH**/ ?>