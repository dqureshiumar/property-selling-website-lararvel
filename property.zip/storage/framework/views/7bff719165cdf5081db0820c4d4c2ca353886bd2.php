    
    <?php $__env->startSection('content'); ?>
        <!-- START SLIDER -->
        <!-- START REVOLUTION SLIDER 5.0.7 fullwidth mode -->
        <div id="rev_slider_home_wrapper" class="rev_slider_wrapper fullwidthbanner-container" data-alias="news-gallery34" style="margin:0px auto;background-color:#ffffff;padding:0px;margin-top:0px;margin-bottom:0px;">
            <div id="rev_slider_home" class="rev_slider fullwidthabanner" style="display:none;" data-version="5.0.7">
                <ul>
                    <!-- SLIDE 1 -->
                    <li data-index="rs-1" data-transition="slidingoverlayhorizontal" data-slotamount="default" data-easein="default" data-easeout="default" data-masterspeed="default" data-thumb="<?php echo e(asset('images')); ?>/slider/slider-1.jpg" data-rotate="0" data-fstransition="fade" data-fsmasterspeed="1500" data-fsslotamount="7" data-saveperformance="off" data-title="Make an Impact">
                        <!-- MAIN IMAGE -->
                        <img src="<?php echo e(asset('images')); ?>/slider/slider-1.jpg" alt data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="10" class="rev-slidebg" data-no-retina>
                        <!-- LAYERS -->
                        <!-- LAYER NR. 1 -->
                        <div class="tp-caption tp-shape tp-shapewrapper tp-resizeme rs-parallaxlevel-0" id="slide-1-layer-1" data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" data-y="['middle','middle','middle','middle']" data-voffset="['0','0','0','0']" data-width="full" data-height="full" data-whitespace="normal" data-transform_idle="o:1;" data-transform_in="opacity:0;s:1500;e:Power3.easeInOut;" data-transform_out="opacity:0;s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;" data-start="1000" data-basealign="slide" data-responsive_offset="on" style="z-index: 5;background-color:rgba(0, 0, 0, 0.35);border-color:rgba(0, 0, 0, 1.00);">
                        </div>
                        <!-- LAYER NR. 2 -->
                        <div class="tp-caption tp-resizeme text-white rs-parallaxlevel-0" id="slide-1-layer-2" data-x="['left','left','left','left']" data-hoffset="['50','50','50','30']" data-y="['top','top','top','top']" data-voffset="['120','100','70','90']" data-fontsize="['56','46','40','36']" data-lineheight="['70','60','50','45']" data-fontweight="['800','700','700','700']" data-width="['700','650','600','420']" data-height="none" data-whitespace="normal" data-transform_idle="o:1;" data-transform_in="y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;" data-transform_out="auto:auto;s:1000;e:Power3.easeInOut;" data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" data-mask_out="x:0;y:0;s:inherit;e:inherit;" data-start="1000" data-splitin="none" data-splitout="none" data-responsive_offset="on" style="z-index: 6; min-width: 600px; max-width: 600px; white-space: normal;">This is the <span class="text-theme-colored2"></span> best <span class="text-theme-colored2">Real Estate </span>Web Site.
                        </div>
                        <!-- LAYER NR. 3 -->
                        <div class="tp-caption tp-resizeme text-white rs-parallaxlevel-0 font-p" id="slide-1-layer-3" data-x="['left','left','left','left']" data-hoffset="['50','50','50','30']" data-y="['top','top','top','top']" data-voffset="['280','220','180','180']" data-fontsize="['18','18','16','13']" data-lineheight="['30','30','28','25']" data-fontweight="['600','600','600','600']" data-width="['700','650','600','420']" data-height="none" data-whitespace="nowrap" data-transform_idle="o:1;" data-transform_in="y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;" data-transform_out="auto:auto;s:1000;e:Power3.easeInOut;" data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" data-mask_out="x:0;y:0;s:inherit;e:inherit;" data-start="1000" data-splitin="none" data-splitout="none" data-responsive_offset="on" style="z-index: 7; white-space: nowrap;">We provides always our best services for our clients and always
                            <br> try to achieve our client's trust and satisfaction.
                        </div>
                        <!-- LAYER NR. 4 -->
                        <div class="tp-caption tp-resizeme text-white rs-parallaxlevel-0" id="slide-1-layer-4" data-x="['left','left','left','left']" data-hoffset="['53','53','53','30']" data-y="['top','top','top','top']" data-voffset="['360','290','260','260']" data-fontsize="['18','18','16','16']" data-lineheight="['30','30','30','30']" data-fontweight="['600','600','600','600']" data-width="['700','650','600','420']" data-height="none" data-whitespace="nowrap" data-transform_idle="o:1;" data-transform_in="y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;" data-transform_out="auto:auto;s:1000;e:Power3.easeInOut;" data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" data-mask_out="x:0;y:0;s:inherit;e:inherit;" data-start="1000" data-splitin="none" data-splitout="none" data-responsive_offset="on" style="z-index: 7; white-space: nowrap;"><a href="/about-us" class="btn btn-default btn-theme-colored2 btn-xl">Read More</a> <a href="/contact-us" class="btn btn-dark btn-theme-colored btn-xl">Contact Us</a>
                        </div>
                    </li>

                    <!-- SLIDE 2 -->
                    <li data-index="rs-2" data-transition="slidingoverlayhorizontal" data-slotamount="default" data-easein="default" data-easeout="default" data-masterspeed="default" data-thumb="<?php echo e(asset('images')); ?>/slider/slider-2.jpg" data-rotate="0" data-fstransition="fade" data-fsmasterspeed="1500" data-fsslotamount="7" data-saveperformance="off" data-title="Make an Impact">
                        <!-- MAIN IMAGE -->
                        <img src="<?php echo e(asset('images')); ?>/slider/slider-2.jpg" alt data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="10" class="rev-slidebg" data-no-retina>
                        <!-- LAYERS -->
                        <!-- LAYER NR. 1 -->
                        <div class="tp-caption tp-shape tp-shapewrapper tp-resizeme rs-parallaxlevel-0" id="slide-2-layer-1" data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" data-y="['middle','middle','middle','middle']" data-voffset="['0','0','0','0']" data-width="full" data-height="full" data-whitespace="normal" data-transform_idle="o:1;" data-transform_in="opacity:0;s:1500;e:Power3.easeInOut;" data-transform_out="opacity:0;s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;" data-start="1000" data-basealign="slide" data-responsive_offset="on" style="z-index: 5;background-color:rgba(0, 0, 0, 0.35);border-color:rgba(0, 0, 0, 1.00);">
                        </div>
                        <!-- LAYER NR. 2 -->
                        <div class="tp-caption tp-resizeme text-white rs-parallaxlevel-0" id="slide-2-layer-2" data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" data-y="['top','top','top','top']" data-voffset="['120','100','70','90']" data-fontsize="['28','24','24','24']" data-lineheight="['33','30','30','30']" data-fontweight="['600','600','600','600']" data-textalign="['center','center','center','center']" data-width="none" data-height="none" data-whitespace="nowrap" data-transform_idle="o:1;" data-transform_in="y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;" data-transform_out="auto:auto;s:1000;e:Power3.easeInOut;" data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" data-mask_out="x:0;y:0;s:inherit;e:inherit;" data-start="1000" data-splitin="none" data-splitout="none" data-responsive_offset="on" style="z-index: 7; white-space: nowrap;">Online Solution
                        </div>
                        <!-- LAYER NR. 3 -->
                        <div class="tp-caption tp-resizeme text-white rs-parallaxlevel-0" id="slide-2-layer-3" data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" data-y="['top','top','top','top']" data-voffset="['165','135','105','130']" data-fontsize="['56','46','40','36']" data-lineheight="['70','60','50','45']" data-fontweight="['800','700','700','700']" data-textalign="['center','center','center','center']" data-width="['700','650','600','420']" data-height="none" data-whitespace="normal" data-transform_idle="o:1;" data-transform_in="y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;" data-transform_out="auto:auto;s:1000;e:Power3.easeInOut;" data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" data-mask_out="x:0;y:0;s:inherit;e:inherit;" data-start="1000" data-splitin="none" data-splitout="none" data-responsive_offset="on" style="z-index: 6; min-width: 600px; max-width: 600px; white-space: normal;">Grow Up<span class="text-theme-colored2"> Business</span> Choose <span class="text-theme-colored2">Right</span> Solution.
                        </div>
                        <!-- LAYER NR. 4 -->
                        <div class="tp-caption tp-resizeme text-white rs-parallaxlevel-0 font-p" id="slide-2-layer-4" data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" data-y="['top','top','top','top']" data-voffset="['320','260','220','220']" data-fontsize="['18','18','16','13']" data-lineheight="['30','30','28','25']" data-fontweight="['600','600','600','600']" data-textalign="['center','center','center','center']" data-width="['700','650','600','420']" data-height="none" data-whitespace="nowrap" data-transform_idle="o:1;" data-transform_in="y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;" data-transform_out="auto:auto;s:1000;e:Power3.easeInOut;" data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" data-mask_out="x:0;y:0;s:inherit;e:inherit;" data-start="1000" data-splitin="none" data-splitout="none" data-responsive_offset="on" style="z-index: 7; white-space: nowrap;">We provides always our best services for our clients and always
                            <br> try to achieve our client's trust and satisfaction.
                        </div>
                        <!-- LAYER NR. 5 -->
                        <div class="tp-caption tp-resizeme text-white rs-parallaxlevel-0" id="slide-2-layer-5" data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" data-y="['top','top','top','top']" data-voffset="['400','340','300','300']" data-fontsize="['18','18','16','16']" data-lineheight="['30','30','30','30']" data-fontweight="['600','600','600','600']" data-width="none" data-height="none" data-whitespace="nowrap" data-transform_idle="o:1;" data-transform_in="y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;" data-transform_out="auto:auto;s:1000;e:Power3.easeInOut;" data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" data-mask_out="x:0;y:0;s:inherit;e:inherit;" data-start="1000" data-splitin="none" data-splitout="none" data-responsive_offset="on" style="z-index: 7; white-space: nowrap;"><a href="#" class="btn btn-dark btn-theme-colored btn-xl">Read More</a>
                        </div>
                    </li>

                    <!-- SLIDE 3 -->
                    <li data-index="rs-3" data-transition="slidingoverlayhorizontal" data-slotamount="default" data-easein="default" data-easeout="default" data-masterspeed="default" data-thumb="<?php echo e(asset('images')); ?>/slider/slider-3.jpg" data-rotate="0" data-fstransition="fade" data-fsmasterspeed="1500" data-fsslotamount="7" data-saveperformance="off" data-title="Make an Impact">
                        <!-- MAIN IMAGE -->
                        <img src="<?php echo e(asset('images')); ?>/slider/slider-3.jpg" alt data-bgposition="top 20%" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="10" class="rev-slidebg" data-no-retina>
                        <!-- LAYERS -->
                        <!-- LAYER NR. 1 -->
                        <div class="tp-caption tp-shape tp-shapewrapper tp-resizeme rs-parallaxlevel-0" id="slide-3-layer-1" data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" data-y="['middle','middle','middle','middle']" data-voffset="['0','0','0','0']" data-width="full" data-height="full" data-whitespace="normal" data-transform_idle="o:1;" data-transform_in="opacity:0;s:1500;e:Power3.easeInOut;" data-transform_out="opacity:0;s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;" data-start="1000" data-basealign="slide" data-responsive_offset="on" style="z-index: 5;background-color:rgba(0, 0, 0, 0.25);border-color:rgba(0, 0, 0, 1.00);">
                        </div>
                        <!-- LAYER NR. 2 -->
                        <div class="tp-caption tp-resizeme text-white rs-parallaxlevel-0" id="slide-3-layer-2" data-x="['center','center','center','center']" data-hoffset="['310','200','100','0']" data-y="['top','top','top','top']" data-voffset="['120','100','70','90']" data-fontsize="['56','46','40','36']" data-lineheight="['70','60','50','45']" data-fontweight="['800','700','700','700']" data-width="['700','650','500','420']" data-height="none" data-whitespace="normal" data-transform_idle="o:1;" data-transform_in="y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;" data-transform_out="auto:auto;s:1000;e:Power3.easeInOut;" data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" data-mask_out="x:0;y:0;s:inherit;e:inherit;" data-start="1000" data-splitin="none" data-splitout="none" data-responsive_offset="on" style="z-index: 6; min-width: 600px; max-width: 600px; white-space: normal;">We help you <span class="text-theme-colored2">business</span> to grow and expand
                        </div>
                        <!-- LAYER NR. 3 -->
                        <div class="tp-caption tp-resizeme text-white rs-parallaxlevel-0 font-p" id="slide-3-layer-3" data-x="['center','center','center','center']" data-hoffset="['310','200','100','0']" data-y="['top','top','top','top']" data-voffset="['280','220','180','180']" data-fontsize="['18','18','16','13']" data-lineheight="['30','30','28','25']" data-fontweight="['600','600','600','600']" data-width="['700','650','500','420']" data-height="none" data-whitespace="nowrap" data-transform_idle="o:1;" data-transform_in="y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;" data-transform_out="auto:auto;s:1000;e:Power3.easeInOut;" data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" data-mask_out="x:0;y:0;s:inherit;e:inherit;" data-start="1000" data-splitin="none" data-splitout="none" data-responsive_offset="on" style="z-index: 7; white-space: nowrap;">We provides always our best services for our clients and always
                            <br> try to achieve our client's trust and satisfaction.
                        </div>
                        <!-- LAYER NR. 3 -->
                        <div class="tp-caption tp-resizeme text-white rs-parallaxlevel-0" id="slide-3-layer-4" data-x="['center','center','center','center']" data-hoffset="['310','200','100','0']" data-y="['top','top','top','top']" data-voffset="['360','290','260','260']" data-fontsize="['18','18','16','16']" data-lineheight="['30','30','30','30']" data-fontweight="['600','600','600','600']" data-width="['700','650','500','420']" data-height="none" data-whitespace="nowrap" data-transform_idle="o:1;" data-transform_in="y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;" data-transform_out="auto:auto;s:1000;e:Power3.easeInOut;" data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" data-mask_out="x:0;y:0;s:inherit;e:inherit;" data-start="1000" data-splitin="none" data-splitout="none" data-responsive_offset="on" style="z-index: 7; white-space: nowrap;"><a href="#" class="btn btn-dark btn-theme-colored btn-xl">Read More</a>
                        </div>
                        <!-- LAYER NR. 4 -->
                        <div class="tp-caption rs-parallaxlevel-0" id="slide-3-layer-5" data-x="['center','center','center','center']" data-hoffset="['310','33','0','0']" data-y="['top','top','top','top']" data-voffset="['360','290','260','260']" data-width="['700','650','600','420']" data-height="none" data-whitespace="nowrap" data-transform_idle="o:1;" data-transform_hover="o:1;rX:0;rY:0;rZ:0;z:0;s:300;e:Power1.easeInOut;" data-transform_in="y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;" data-transform_out="auto:auto;s:1000;e:Power3.easeInOut;" data-mask_in="x:0px;y:0px;" data-mask_out="x:0;y:0;" data-start="1000" data-splitin="none" data-splitout="none" data-responsive_offset="on" data-responsive="off" style="z-index: 8; white-space: nowrap;outline:none;box-shadow:none;box-sizing:border-box;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;">
                        </div>
                    </li>
                </ul>
                <div class="tp-bannertimer tp-bottom" style="height: 5px; background-color: #0098ef;"></div>
            </div>
        </div>
        <!-- END REVOLUTION SLIDER -->
        <!-- END SECTION HEADINGS -->

        <!-- START SECTION SEARCH AREA -->
        
        <!-- END SECTION SEARCH AREA -->

        <!-- START SECTION RECENTLY PROPERTIES -->
        <section class="recently portfolio">
            <div class="container-fluid">
                <div class="section-title">
                    <h3>Recently</h3>
                    <h2>Properties</h2>
                </div>
                <div class="row portfolio-items">
                    <?php $__currentLoopData = $recents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="item col-lg-3 col-md-6 col-xs-12 people">
                        <div class="project-single">
                            <div class="project-inner project-head">
                                <div class="project-bottom">
                                    <h4><a href="submit-property/<?php echo e($recent->id); ?>">View Property</a><span class="category">Real Estate</span></h4>
                                </div>
                                <div class="button-effect">
                                    <a href="submit-property/<?php echo e($recent->id); ?>" class="btn"><i class="fa fa-link"></i></a>
                                    
                                    <?php
                                        $images = explode("|",$recent->filename);
                                    ?>
                                    <a class="img-poppu btn" href="<?php echo e(asset('storage')); ?>/image/<?php echo e($images[0]); ?>" data-rel="lightcase:myCollection:slideshow"><i class="fa fa-photo"></i></a>
                                </div>
                                <div class="homes">
                                    <!-- homes img -->
                                    <a href="submit-property/<?php echo e($recent->id); ?>" class="homes-img">
                                        <?php if($recent->featured == 1): ?> <div class="homes-tag button alt featured">Featured</div> <?php endif; ?>
                                        <?php if($recent->status == "For Rent"): ?> <div class="homes-tag button sale rent">For Rent</div> <?php else: ?> <div class="homes-tag button alt sale">For Sale</div><?php endif; ?>
                                        <?php if($recent->status == "Family Home"): ?><div class="homes-price">Family Home</div> <?php else: ?> <div class="homes-price">Apartment</div><?php endif; ?>
                                        <img src="<?php echo e(asset('storage')); ?>/image/<?php echo e($images[0]); ?>" alt="home-1" class="img-responsive">
                                    </a>
                                </div>
                            </div>
                            <!-- homes content -->
                            <div class="homes-content">
                                <!-- homes address -->
                                <h3><?php echo e($recent->location); ?></h3>
                                <p class="homes-address mb-3">
                                    <a href="submit-property/<?php echo e($recent->id); ?>">
                                        <i class="fa fa-map-marker"></i><span><?php echo e($recent->address); ?></span>
                                    </a>
                                </p>
                                <!-- homes List -->
                                <ul class="homes-list clearfix">
                                    <li>
                                        <i class="fa fa-bed" aria-hidden="true"></i>
                                        <span><?php echo e($recent->beds); ?> Bedrooms</span>
                                    </li>
                                    <li>
                                        <i class="fa fa-bath" aria-hidden="true"></i>
                                        <span><?php echo e($recent->baths); ?> Bathrooms</span>
                                    </li>
                                    <li>
                                        <i class="fa fa-object-group" aria-hidden="true"></i>
                                        <span><?php echo e($recent->sqft); ?> sq ft</span>
                                    </li>
                                    
                                </ul>
                                <!-- Price -->
                                <div class="price-properties">
                                    <h3 class="title mt-3">
                                    <a href="submit-property/<?php echo e($recent->id); ?>">&#8377; <?php echo e($recent->price); ?></a>
                                    </h3>
                                    <div class="compare">
                                            <?php
                                            $tmp = \App\User::find($recent->userid);
                                            ?>
                                        <a href="tel:<?php echo e($tmp->phone); ?>" title="Call">
                                            <i class="fas fa-phone"></i>
                                        </a>
                                        <a href="mailto:<?php echo e($tmp->email); ?>" title="Share">
                                            <i class="fas fa-envelope"></i>
                                        </a>
                                        
                                    </div>
                                </div>
                                <div class="footer">
                                    <a href="agent-details.html">
                                        <i class="fa fa-user"></i> 
                                        <?php echo e($tmp->name); ?>

                                    </a>
                                    <span>
                                    
                                </span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            
        </section>
        <!-- END SECTION RECENTLY PROPERTIES -->

        <!-- STAR SECTION WELCOME -->
        <section class="welcome">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-md-12 col-xs-12">
                        <div class="welcome-title">
                            <h2>WELCOME TO <span>FIND HOUSES</span></h2>
                            <h4>THE BEST PLACE TO FIND THE HOUSE YOU WANT.</h4>
                        </div>
                        <div class="welcome-content">
                            <p> <span>IndiAvenue</span> is the best place for users who are willing to sell or buy a property in a legit way. There are hundreds of available properties here for the users in different places. Different poeple are able to buy different properties based on their needs.</p>
                        </div>
                        <div class="welcome-services">
                            <div class="row">
                                <div class="col-lg-6 col-md-6 col-xs-12 ">
                                    <div class="w-single-services">
                                        <div class="services-img img-1">
                                            <img src="<?php echo e(asset('images')); ?>/1.png" width="32" alt>
                                        </div>
                                        <div class="services-desc">
                                            <h6>Buy Property</h6>
                                            <p>We have the best properties
                                                <br> for our users</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-xs-12 ">
                                    <div class="w-single-services">
                                        <div class="services-img img-2">
                                            <img src="<?php echo e(asset('images')); ?>/2.png" width="32" alt>
                                        </div>
                                        <div class="services-desc">
                                            <h6>Rent Property</h6>
                                            <p>We provide legit best
                                                <br> properties over rent</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-xs-12 ">
                                    <div class="w-single-services no-mb mbx">
                                        <div class="services-img img-3">
                                            <img src="<?php echo e(asset('images')); ?>/3.png" width="32" alt>
                                        </div>
                                        <div class="services-desc">
                                            <h6>Real Estate Kit</h6>
                                            <p>This is the best real
                                                <br> estate kit.</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-xs-12 ">
                                    <div class="w-single-services no-mb">
                                        <div class="services-img img-4">
                                            <img src="<?php echo e(asset('images')); ?>/4.png" width="32" alt>
                                        </div>
                                        <div class="services-desc">
                                            <h6>Sell/Rent Property</h6>
                                            <p>Hurry Up!! Sell/Rent your
                                                <br> properties here</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12 col-xs-12">
                        <div class="wprt-image-video w50">
                            <img alt="image" src="<?php echo e(asset('images')); ?>/projects/welcome.jpg">
                            <a class="icon-wrap popup-video popup-youtube" href="https://www.youtube.com/watch?v=2xHQqYRcrx4">
                                <i class="fa fa-play"></i>
                            </a>
                            <div class="iq-waves">
                                <div class="waves wave-1"></div>
                                <div class="waves wave-2"></div>
                                <div class="waves wave-3"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- END SECTION WELCOME -->

        <!-- START SECTION SERVICES -->
        <section class="services-home bg-white">
            <div class="container">
                <div class="section-title">
                    <h3>Property</h3>
                    <h2>Services</h2>
                </div>
                <div class="row">
                    <div class="col-lg-4 col-md-12 m-top-0 m-bottom-40">
                        <div class="service bg-light-2 border-1 border-light box-shadow-1 box-shadow-2-hover">
                            <div class="media">
                                <i class="fa fa-home bg-base text-white rounded-100 box-shadow-1 p-top-5 p-bottom-5 p-right-5 p-left-5"></i>
                            </div>
                            <div class="agent-section p-top-35 p-bottom-30 p-right-25 p-left-25">
                                <h4 class="m-bottom-15 text-bold-700">Houses</h4>
                                <p>We Help you to Find your dream home.We also provide legit properties for our end users.Here the seller can also sell their properties, so no need for brokers.</p>
                                
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-12 m-top-40 m-bottom-40">
                        <div class="service bg-light-2 border-1 border-light box-shadow-1 box-shadow-2-hover">
                            <div class="media">
                                <i class="fas fa-building bg-base text-white rounded-100 box-shadow-1 p-top-5 p-bottom-5 p-right-5 p-left-5"></i>
                            </div>
                            <div class="agent-section p-top-35 p-bottom-30 p-right-25 p-left-25">
                                <h4 class="m-bottom-15 text-bold-700">Apartments</h4>
                                <p>We help you find the best Apartments according to your wish with all over faclities listed and in a reasonable price.Kindly contact the user if you got a apartment of your choice.</p>
                                
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-12 m-top-40 m-bottom-40 commercial">
                        <div class="service bg-light-2 border-1 border-light box-shadow-1 box-shadow-2-hover">
                            <div class="media">
                                <i class="fas fa-warehouse bg-base text-white rounded-100 box-shadow-1 p-top-5 p-bottom-5 p-right-5 p-left-5"></i>
                            </div>
                            <div class="agent-section p-top-35 p-bottom-30 p-right-25 p-left-25">
                                <h4 class="m-bottom-15 text-bold-700">Commercial</h4>
                                <p>Once can buy, sell commercial properties here.</p>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- END SECTION SERVICES -->

        <!-- START SECTION FEATURED PROPERTIES -->
        <section class="featured portfolio">
            <div class="container">
                <div class="row">
                    <div class="section-title col-md-5">
                        <h3>Featured</h3>
                        <h2>Properties</h2>
                    </div>
                </div>
                <div class="row portfolio-items">
                    <?php $__currentLoopData = $featureds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $featured): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $f_images = explode("|",$featured->filename);
                    ?>
                    <div class="item col-lg-4 col-md-6 col-xs-12 landscapes sale">
                        <div class="project-single">
                            <div class="project-inner project-head">
                                <div class="project-bottom">
                                    <h4><a href="submit-property/<?php echo e($featured->id); ?>">View Property</a><span class="category">Real Estate</span></h4>
                                </div>
                                <div class="button-effect">
                                    <a href="submit-property/<?php echo e($featured->id); ?>" class="btn"><i class="fa fa-link"></i></a>
                                    
                                    <a class="img-poppu btn" href="<?php echo e(asset('storage')); ?>/image/<?php echo e($f_images[0]); ?>" data-rel="lightcase:myCollection:slideshow"><i class="fa fa-photo"></i></a>
                                </div>
                                <div class="homes">
                                    <!-- homes img -->
                                    <a href="submit-property/<?php echo e($featured->id); ?>" class="homes-img">
                                        <div class="homes-tag button alt featured">Featured</div>
                                        <?php if($featured->status == "For Rent"): ?> <div class="homes-tag button sale rent">For Rent</div> <?php else: ?> <div class="homes-tag button alt sale">For Sale</div><?php endif; ?>
                                        <div class="homes-price"><?php echo e($featured->type); ?></div>
                                        <img src="<?php echo e(asset('storage')); ?>/image/<?php echo e($f_images[0]); ?>" alt="home-1" class="img-responsive">
                                    </a>
                                </div>
                            </div>
                            <!-- homes content -->
                            <div class="homes-content">
                                <!-- homes address -->
                                <h3><?php echo e($featured->location); ?></h3>
                                <p class="homes-address mb-3">
                                    <a href="submit-property/<?php echo e($recent->id); ?>">
                                        <i class="fa fa-map-marker"></i><span><?php echo e($featured->address); ?></span>
                                    </a>
                                </p>
                                <!-- homes List -->
                                <ul class="homes-list clearfix">
                                    <li>
                                        <i class="fa fa-bed" aria-hidden="true"></i>
                                        <span><?php echo e($featured->baths); ?> Bedrooms</span>
                                    </li>
                                    <li>
                                        <i class="fa fa-bath" aria-hidden="true"></i>
                                        <span><?php echo e($featured->beds); ?> Bathrooms</span>
                                    </li>
                                    <li>
                                        <i class="fa fa-object-group" aria-hidden="true"></i>
                                        <span><?php echo e($featured->sqft); ?> sq ft</span>
                                    </li>
                                    
                                </ul>
                                <!-- Price -->
                                <div class="price-properties">
                                    <h3 class="title mt-3">
                                    <a href="submit-property/<?php echo e($recent->id); ?>">&#8377; <?php echo e($featured->price); ?></a>
                                    </h3>
                                    <?php
                                        $tmp1 = \App\User::find($featured->userid);
                                    ?>
                                    <div class="compare">
                                        <a href="tel:<?php echo e($tmp1->phone); ?>" title="Call">
                                            <i class="fas fa-phone"></i>
                                        </a>
                                        <a href="mailto:<?php echo e($tmp1->email); ?>" title="Mail">
                                            <i class="fas fa-envelope"></i>
                                        </a>
                                        
                                    </div>
                                </div>
                                <div class="footer">
                                    <a href="agent-details.html">
                                        <i class="fa fa-user"></i> <?php echo e($tmp1->name); ?>

                                    </a>
                                    <span>
                                    
                                </span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </section>
        <!-- END SECTION FEATURED PROPERTIES -->

        <!-- START SECTION POPULAR PLACES -->
        
        <!-- END SECTION POPULAR PLACES -->

        <!-- START SECTION AGENTS -->
        
        <!-- END SECTION AGENTS -->

        <!-- START SECTION TOP LOCATION -->
        
        <!-- END SECTION TOP LOCATION -->

        <!-- START SECTION BLOG -->
        <section class="blog-section">
            <div class="container">
                <div class="section-title">
                    <h3>Latest</h3>
                    <h2>News</h2>
                </div>
                <div class="news-wrap">
                    <div class="row">
                        <div class="col-xl-6 col-md-12 col-xs-12">
                            <div class="news-item news-item-sm">
                                <a href="blog-details.html" class="news-img-link">
                                    <div class="news-item-img">
                                        <img class="resp-img" src="<?php echo e(asset('images')); ?>/blog/b-1.jpg" alt="blog image">
                                    </div>
                                </a>
                                <div class="news-item-text">
                                    <a href="blog-details.html"><h3>The Real Estate News</h3></a>
                                    <span class="date">Jun 23, 2018 &nbsp;/&nbsp; By Admin</span>
                                    <div class="news-item-descr">
                                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor.</p>
                                    </div>
                                    <div class="news-item-bottom">
                                        <a href="blog-details.html" class="news-link">Read more...</a>
                                        <ul class="action-list">
                                            <li class="action-item"><i class="fa fa-heart"></i> <span>306</span></li>
                                            <li class="action-item"><i class="fa fa-comment"></i> <span>34</span></li>
                                            <li class="action-item"><i class="fa fa-share-alt"></i> <span>122</span></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="news-item news-item-sm mb">
                                <a href="blog-details.html" class="news-img-link">
                                    <div class="news-item-img">
                                        <img class="resp-img" src="<?php echo e(asset('images')); ?>/blog/b-2.jpg" alt="blog image">
                                    </div>
                                </a>
                                <div class="news-item-text">
                                    <a href="blog-details.html"><h3>The Real Estate News</h3></a>
                                    <span class="date">Jun 23, 2018 &nbsp;/&nbsp; By Admin</span>
                                    <div class="news-item-descr">
                                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor.</p>
                                    </div>
                                    <div class="news-item-bottom">
                                        <a href="blog-details.html" class="news-link">Read more...</a>
                                        <ul class="action-list">
                                            <li class="action-item"><i class="fa fa-heart"></i> <span>306</span></li>
                                            <li class="action-item"><i class="fa fa-comment"></i> <span>34</span></li>
                                            <li class="action-item"><i class="fa fa-share-alt"></i> <span>122</span></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-6 col-md-12 col-xs-12">
                            <div class="news-item news-item-sm">
                                <a href="blog-details.html" class="news-img-link">
                                    <div class="news-item-img">
                                        <img class="resp-img" src="<?php echo e(asset('images')); ?>/blog/b-3.jpg" alt="blog image">
                                    </div>
                                </a>
                                <div class="news-item-text">
                                    <a href="blog-details.html"><h3>The Real Estate News</h3></a>
                                    <span class="date">Jun 23, 2018 &nbsp;/&nbsp; By Admin</span>
                                    <div class="news-item-descr">
                                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor.</p>
                                    </div>
                                    <div class="news-item-bottom">
                                        <a href="blog-details.html" class="news-link">Read more...</a>
                                        <ul class="action-list">
                                            <li class="action-item"><i class="fa fa-heart"></i> <span>306</span></li>
                                            <li class="action-item"><i class="fa fa-comment"></i> <span>34</span></li>
                                            <li class="action-item"><i class="fa fa-share-alt"></i> <span>122</span></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="news-item news-item-sm">
                                <a href="blog-details.html" class="news-img-link">
                                    <div class="news-item-img">
                                        <img class="resp-img" src="<?php echo e(asset('images')); ?>/blog/b-4.jpg" alt="blog image">
                                    </div>
                                </a>
                                <div class="news-item-text">
                                    <a href="blog-details.html"><h3>The Real Estate News</h3></a>
                                    <span class="date">Jun 23, 2018 &nbsp;/&nbsp; By Admin</span>
                                    <div class="news-item-descr">
                                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor.</p>
                                    </div>
                                    <div class="news-item-bottom">
                                        <a href="blog-details.html" class="news-link">Read more...</a>
                                        <ul class="action-list">
                                            <li class="action-item"><i class="fa fa-heart"></i> <span>306</span></li>
                                            <li class="action-item"><i class="fa fa-comment"></i> <span>34</span></li>
                                            <li class="action-item"><i class="fa fa-share-alt"></i> <span>122</span></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- END SECTION BLOG -->

        <!-- START SECTION TESTIMONIALS -->
        
        <!-- END SECTION TESTIMONIALS -->

        <!-- STAR SECTION PARTNERS -->
        
        <!-- END SECTION PARTNERS -->

        <!-- START SECTION COUNTER UP -->
        <section class="counterup">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-md-6 col-xs-12">
                        <div class="countr">
                            <i class="fa fa-home" aria-hidden="true"></i>
                            <div class="count-me">
                                <p class="counter text-left">300</p>
                                <h3>Sold Houses</h3>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-xs-12">
                        <div class="countr">
                            <i class="fa fa-list" aria-hidden="true"></i>
                            <div class="count-me">
                                <p class="counter text-left">400</p>
                                <h3>Daily Listings</h3>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-xs-12">
                        <div class="countr mb-0">
                            <i class="fa fa-users" aria-hidden="true"></i>
                            <div class="count-me">
                                <p class="counter text-left">250</p>
                                <h3>Expert Agents</h3>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-xs-12">
                        <div class="countr mb-0 last">
                            <i class="fa fa-trophy" aria-hidden="true"></i>
                            <div class="count-me">
                                <p class="counter text-left">200</p>
                                <h3>Won Awars</h3>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- END SECTION COUNTER UP -->

        <!-- START SECTION NEWSLETTER -->
        <section class="subscribe">
            <div class="realhome_subscribe">
                <div class="realhome container">
                    <h2>Subscribe for Our Newsletter</h2>
                    <div class="row align-center">
                        <div class="col-lg-6 col-md-6">
                            <form class="realhome_form_subscribe mailchimp form-inline" method="post">
                                <input type="email" id="subscribeEmail" name="EMAIL" class="form_email" placeholder="Enter Your Email">
                                <button type="submit" value="Subscribe">Submit</button>
                                <label for="subscribeEmail" class="error"></label>
                                <p class="subscription-success"></p>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- END SECTION NEWSLETTER -->

     <?php $__env->stopSection(); ?>

<?php echo $__env->make('property.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\dqure\Desktop\property\property\resources\views/property/index.blade.php ENDPATH**/ ?>