<link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('images')); ?>/favicon.ico">
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('users.partials.header', [
        'title' => __('Hello') . ' '. auth()->user()->name,
        'description' => __('Submit your Property now and Send us for Verification of your property.Incase your property is Legit, your Property will be Displayed on our Website.Thank You!!'),
        'class' => 'col-lg-7'
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>   

    <div class="container-fluid mt--7">
        <div class="row">
            <div class="col-xl-4 order-xl-2 mb-5 mb-xl-0">
                <div class="card card-profile shadow">
                    <div class="row justify-content-center">
                        <div class="col-lg-3 order-lg-2">
                            <div class="card-profile-image">
                                <a href="#">
                                    <img src="<?php echo e(asset('images')); ?>/default.png" class="rounded-circle">
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="card-header text-center border-0 pt-8 pt-md-4 pb-0 pb-md-4">
                        <div class="d-flex justify-content-between">
                            <a href="#" class="btn btn-sm btn-info mr-4"><?php echo e(__('Change Photo')); ?></a>
                        </div>
                    </div>
                    <div class="card-body pt-0 pt-md-4">
                        <div class="row">
                            <div class="col">
                                <div class="card-profile-stats d-flex justify-content-center mt-md-5">
                                    <div>
                                        <span class="heading">22</span>
                                        <span class="description"><?php echo e(__('Properties')); ?></span>
                                    </div>
                                    <div>
                                        <span class="heading">10</span>
                                        <span class="description"><?php echo e(__('Under Verification')); ?></span>
                                    </div>
                                    <div>
                                        <span class="heading">89</span>
                                        <span class="description"><?php echo e(__('Sold')); ?></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="text-center">
                            <h3>
                                <?php echo e(auth()->user()->name); ?><span class="font-weight-light"></span>
                            </h3>
                            <div class="h5 font-weight-300">
                                <i class="ni location_pin mr-2"></i><?php echo e(__('Mumbai, India')); ?>

                            </div>
                            <div class="h5 mt-4">
                                <i class="ni business_briefcase-24 mr-2"></i><?php echo e(__('')); ?>

                            </div>
                            <div>
                                <i class="ni education_hat mr-2"></i><?php echo e(__('A Good Human Being')); ?>

                            </div>
                            <hr class="my-4" />
                            
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-8 order-xl-1">
                <div class="card bg-secondary shadow">
                    <div class="card-header bg-white border-0">
                        <div class="row align-items-center">
                            <h3 class="col-12 mb-0"><?php echo e(__('Submit your Property')); ?></h3>
                        </div>
                    </div>
                    <div class="card-body">
                        <form method="post" action="<?php echo e(route('submit-property.store')); ?>" autocomplete="off" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>

                            <h6 class="heading-small text-muted mb-4"><?php echo e(__('Property information')); ?></h6>
                            
                            <?php if(session('status')): ?>
                                <div class="alert alert-success alert-dismissible fade show" role="alert">
                                    <?php echo e(session('status')); ?>

                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            <?php endif; ?>

                            <div class="pl-lg-4">
                                <div class="form-group<?php echo e($errors->has('location') ? ' has-danger' : ''); ?>">
                                    <label class="form-control-label" for="input-name"><?php echo e(__('Location')); ?></label>
                                    <input type="text" name="location" id="input-name" class="form-control form-control-alternative<?php echo e($errors->has('location') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Enter your Property Location (Eg: Malad)')); ?>" }}" required autofocus>

                                    <?php if($errors->has('location')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('location')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <label for="exampleFormControlSelect1">Property Status</label>
                                    <select class="form-control" id="exampleFormControlSelect1" name="status">
                                      <option value="For Sale">For Sale</option>
                                      <option value="For Rent">For Rent</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="exampleFormControlSelect2">Property Type</label>
                                    <select class="form-control" id="exampleFormControlSelect2" name="type">
                                      <option value="Family House">Family House</option>
                                      <option value="Apartment">Apartment</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="exampleFormControlSelect3">Beds</label>
                                    <select class="form-control" id="exampleFormControlSelect3" name="beds">
                                      <option value="1">1</option>
                                      <option value="2">2</option>
                                      <option value="3">3</option>
                                      <option value="4">4</option>
                                      <option value="5">5</option>
                                      <option value="6">6</option>
                                      <option value="7">7</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="exampleFormControlSelect4">Baths</label>
                                    <select class="form-control" id="exampleFormControlSelect4" name="baths">
                                      <option value="1">1</option>
                                      <option value="2">2</option>
                                      <option value="3">3</option>
                                      <option value="4">4</option>
                                      <option value="5">5</option>
                                      <option value="6">6</option>
                                      <option value="7">7</option>
                                    </select>
                                </div>
                                <div class="form-group<?php echo e($errors->has('sqft') ? ' has-danger' : ''); ?>">
                                    <label class="form-control-label" for="input-sqft"><?php echo e(__('Square feet')); ?></label>
                                    <input type="text" name="sqft" id="input-sqft" class="form-control form-control-alternative<?php echo e($errors->has('sqft') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Square Feet')); ?>" required>

                                    <?php if($errors->has('sqft')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('sqft')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group<?php echo e($errors->has('price') ? ' has-danger' : ''); ?>">
                                    <label class="form-control-label" for="input-price"><?php echo e(__('Price ')); ?></label>
                                    <input type="text" name="price" id="input-price" class="form-control form-control-alternative<?php echo e($errors->has('price') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Price in Rupees')); ?>" required>

                                    <?php if($errors->has('price')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('price')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group<?php echo e($errors->has('address') ? ' has-danger' : ''); ?>">
                                    <label class="form-control-label" for="input-address"><?php echo e(__('Address ')); ?></label>
                                    <textarea type="text" name="address" id="input-address" class="form-control form-control-alternative<?php echo e($errors->has('address') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Enter your Full Address')); ?>" required></textarea>

                                    <?php if($errors->has('address')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('address')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <label for="filename[]">Upload your Property Image</label>
                                    <input type="file" id="filename[]" class="form-control" name="filename[]" required multiple>
                                </div>
                                
                                <div class="text-center">
                                    
                                    <button type="submit" class="btn btn-success mt-4"><?php echo e(__('Submit')); ?></button>
                                </div>
                            </div>
                        </form>
                        <hr class="my-4" />
                        
                        
                    </div>
                </div>
            </div>
        </div>
        
        <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['title' => __('User Profile')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Home\Desktop\property\resources\views/layouts/submitproperty.blade.php ENDPATH**/ ?>