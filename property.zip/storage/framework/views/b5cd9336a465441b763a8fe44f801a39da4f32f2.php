<div class="row align-items-center justify-content-xl-between">
    <div class="col-xl-6">
        <div class="copyright text-center text-xl-left text-muted">
            &copy; <?php echo e(now()->year); ?> <a href="http://dqureshiumar001.000webhostapp.com/" class="font-weight-bold ml-1" target="_blank"></a>
        </div>
    </div>
    <div class="col-xl-6">
        <ul class="nav nav-footer justify-content-center justify-content-xl-end">
            <li class="nav-item">
                <a href="/" class="nav-link" target="_blank">Home</a>
            </li>
            <li class="nav-item">
                <a href="http://dqureshiumar001.000webhostapp.com/" class="nav-link" target="_blank">UQ</a>
            </li>
            <li class="nav-item">
                <a href="/about-us" class="nav-link" target="_blank">About Us</a>
            </li>
        </ul>
    </div>
</div><?php /**PATH C:\Users\dqure\Desktop\homex\property\resources\views/layouts/footers/nav.blade.php ENDPATH**/ ?>